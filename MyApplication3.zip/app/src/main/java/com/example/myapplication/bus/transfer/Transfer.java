package com.example.myapplication.bus.transfer;

import com.example.myapplication.bus.ComMsgHeader;
import com.example.myapplication.bus.station.MsgBody;
import com.example.myapplication.bus.MsgHeader;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Transfer {

    @SerializedName("comMsgHeader")
    @Expose
    private ComMsgHeader comMsgHeader;
    @SerializedName("msgHeader")
    @Expose
    private MsgHeader msgHeader;
    @SerializedName("msgBody")
    @Expose
    private TMsgBody TmsgBody;

    public ComMsgHeader getComMsgHeader() {
        return comMsgHeader;
    }

    public void setComMsgHeader(ComMsgHeader comMsgHeader) {
        this.comMsgHeader = comMsgHeader;
    }

    public MsgHeader getMsgHeader() {
        return msgHeader;
    }

    public void setMsgHeader(MsgHeader msgHeader) {
        this.msgHeader = msgHeader;
    }

    public TMsgBody getTmsgBody() {
        return TmsgBody;
    }

    public void setTmsgBody(MsgBody msgBody) {
        this.TmsgBody = TmsgBody;
    }
}

