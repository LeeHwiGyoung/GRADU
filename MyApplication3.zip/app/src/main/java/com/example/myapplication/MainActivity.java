package com.example.myapplication;
import static android.os.SystemClock.sleep;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.bus.arrival.Arrival;
import com.example.myapplication.bus.arrival.ArrivalAPI;
import com.example.myapplication.bus.arrival.ArrivalItem;
import com.example.myapplication.bus.arrival.RetrofitArrivalClient;
import com.example.myapplication.bus.station.RetrofitAPI;
import com.example.myapplication.bus.station.RetrofitClient;
import com.example.myapplication.bus.transfer.RetrofitTransferClient;
import com.example.myapplication.bus.station.Station;
import com.example.myapplication.bus.station.StationItem;
import com.example.myapplication.bus.transfer.Transfer;
import com.example.myapplication.bus.transfer.TransferItem;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
public class MainActivity extends AppCompatActivity {
    public List<StationItem> startStationItems; //startstation 정보를 받아오는  list (ArsId정보를 포함)
    private List<TransferItem> mTransferItems; // (routeNm=버스 번호 , fid = 타야하는 버스 정류소 id  = arrivalItems의 stid 와 비교해서 도착 시간을 갖고올 때 사용, Tname 하차지를 갖고 있음)
    private List<ArrivalItem> arrivalItems; // arrmsg1의 정보를 갖고 있는 list (버스의 도착시간 정보를 갖고옴)
    private TextView station_message; //TextView
    String Transfer_key = "uJVPZ36cG4TAmsXg9mpWZHtlod+uxSREmceXmb8+hOU2NDP2G2XcyW4KOua4/PMe+I1P5/MemCn1pNVoNQS8Iw=="; //환승시 사용하는 요청키 (Transfer_Info)에서 사용
    String Station_key = "uJVPZ36cG4TAmsXg9mpWZHtlod+uxSREmceXmb8+hOU2NDP2G2XcyW4KOua4/PMe+I1P5/MemCn1pNVoNQS8Iw=="; // 정류소 고유아이디와 도착정보를 갖고 오는데 사용하는 요청키 (Station_InFo , arriveInfo)
    String type = "json"; // 요청타입
    String startX = "126.9252620559"; // 홍대입구역
    String startY = "37.5577221581";
    String endX = "126.9773320672"; // 연세대앞
    String endY = "37.5722264424";
    String targetfName;// 타야하는 정류장 이름
    String targetfId; // 타야하는 정류장의 고유 번호"113000422";
    String targetArsId;// 타야하는 버스 노선의 고유 번호
    String targetRouteNm; // 타야하는 버스 노선의 이름
    String targetArrival; // 타야하는 버스의 도착 예정 시간

    private RetrofitAPI retrofitAPI;
    private com.example.myapplication.bus.transfer.TransferAPI TransferAPI;
    private com.example.myapplication.bus.arrival.ArrivalAPI ArrivalAPI;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = (Button) findViewById(R.id.button);
        station_message = findViewById(R.id.t);
        button.setOnClickListener(new View.OnClickListener() { // 버튼 클릭하면
            @Override
            public void onClick(View view) {
                Transfer_InFo();
            }
        });
    }

    void Transfer_InFo() {
        RetrofitTransferClient retrofitTransferClient = RetrofitTransferClient.getInstance();
        if (retrofitTransferClient != null) {
            TransferAPI = retrofitTransferClient.getTransferAPI();
            TransferAPI.getTransfer(Transfer_key, startX, startY, endX, endY, type).enqueue(new Callback<Transfer>() { //비동기식으로 API를 호출함
                @Override
                public void onResponse(Call<Transfer> call, Response<Transfer> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        mTransferItems = response.body().getTmsgBody().getItemList();
                        Log.d("mItems 결과값", " response.body().getMsgBody().getItemList().get(0).getPathItemList().get(0).getRouteNm : " + response.body().getTmsgBody().getItemList().get(0).getPathItemList().get(0).getRouteNm());
                        if (mTransferItems != null) {
                            targetfName = mTransferItems.get(0).getPathItemList().get(0).getFname();
                            targetfId = mTransferItems.get(0).getPathItemList().get(0).getFid();
                            targetRouteNm = mTransferItems.get(0).getPathItemList().get(0).getRouteNm();
                            Station_InFo(targetfName); // targetfname에 정보가 저장 된 후 버스정류장 정보를 갖고옴
                        }
                    }
                }

                @Override
                public void onFailure(Call<Transfer> call, Throwable t) {
                    Toast.makeText(MainActivity.this, "network failure", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    void Station_InFo(String s) {
        RetrofitClient retrofitClient = RetrofitClient.getInstance();
        if (retrofitClient != null) {
            retrofitAPI = RetrofitClient.getRetrofitAPI();
            retrofitAPI.getData(Station_key, s, type).enqueue(new Callback<Station>() {
                @Override
                public void onResponse(Call<Station> call, Response<Station> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        startStationItems = response.body().getMsgBody().getItemList();
                        Log.d("head", "head" + response.body().getMsgHeader().getHeaderMsg());
                        for( int i= 0; i < startStationItems.toArray().length; i++ )
                        {
                            Log.d("mItems 결과값",   i +" 번째stID: " + startStationItems.get(i).getStId());
                            if(targetfId.equals(startStationItems.get(i).getStId()))
                            {
                                Log.d("if문 결과값",   i +" 번째ArsId: " + startStationItems.get(i).getArsId());
                                targetArsId = startStationItems.get(i).getArsId();
                                break;
                            }
                            Log.d("mItems 결과값", " stNm: " + startStationItems.get(i).getStNm());
                        }
                        arriveInFo(targetArsId);
                    }
                }

                @Override
                public void onFailure(Call<Station> call, Throwable t) {
                    Toast.makeText(MainActivity.this, "network failure", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    void arriveInFo(String s) { //ArsId
        RetrofitArrivalClient retrofitArrivalClient = RetrofitArrivalClient.getInstance();
        if(retrofitArrivalClient != null){
            ArrivalAPI = RetrofitArrivalClient.getArrivalAPI();
            ArrivalAPI.getArrival(Station_key,s,type).enqueue(new Callback<Arrival>() {
                @Override
                public void onResponse(Call<Arrival> call, Response<Arrival> response) {
                    if (response.isSuccessful() && response.body() != null)
                    {
                        arrivalItems = response.body().getAMsgBody().getArrivalItemList();
                        for(int i = 0; i < arrivalItems.toArray().length;i++){
                            if(targetRouteNm.equals(arrivalItems.get(i).getRtNm())) {
                                targetArrival = arrivalItems.get(i).getArrmsg1();
                                Log.d("도착정보값", " 도착정보값 : " + targetArrival);
                                station_message.setText(targetRouteNm +"버스 도착 예정 시간 : "+targetArrival);
                            }
                        }
                    }
                }
                @Override
                public void onFailure(Call<Arrival> call, Throwable t) {
                    Toast.makeText(MainActivity.this, "network failure", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}








