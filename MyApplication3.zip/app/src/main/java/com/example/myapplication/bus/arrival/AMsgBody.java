package com.example.myapplication.bus.arrival;

import com.example.myapplication.bus.station.StationItem;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class AMsgBody {


    @SerializedName("itemList")
    @Expose
    private List<ArrivalItem> ArrivalItemList = null;

    public List<ArrivalItem> getArrivalItemList() {
        return ArrivalItemList;
    }

    public void setArrivalItemList(List<ArrivalItem> stationItemList) {
        this.ArrivalItemList = stationItemList;
    }

}

