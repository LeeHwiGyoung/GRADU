package com.example.myapplication.bus.station;

import java.util.List;

import com.example.myapplication.bus.station.StationItem;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class MsgBody {

    @SerializedName("itemList")
    @Expose
    private List<StationItem> stationItemList = null;

    public List<StationItem> getItemList() {
        return stationItemList;
    }

    public void setItemList(List<StationItem> stationItemList) {
        this.stationItemList = stationItemList;
    }

}
